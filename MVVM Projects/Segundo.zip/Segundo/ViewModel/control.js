function setTime(tiempo) {

    istiempo = tiempo;
    verificarHoraEspecifica();

}

function isTime(segundos) {

    isCurrentTime(segundos);


} 
